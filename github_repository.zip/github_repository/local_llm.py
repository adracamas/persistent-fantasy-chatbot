"""
Local LLM Interface for Fantasy Chatbot
Works with quantized models to fit in 12GB VRAM
"""

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig, pipeline
from typing import List, Dict, Optional
import logging
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LocalFantasyLLM:
    def __init__(self, model_name: str = "microsoft/DialoGPT-medium"):
        """
        Initialize the local LLM with GPU support.
        
        Args:
            model_name: HuggingFace model name or path
                       Recommended for 12GB VRAM:
                       - "microsoft/DialoGPT-medium" (355M parameters)
                       - "microsoft/DialoGPT-large" (774M parameters) 
                       - "microsoft/DialoGPT-xl" (1.5B parameters)
                       - "meta-llama/Llama-2-7b-chat-hf" (7B parameters, needs quantization)
        """
        self.model_name = model_name
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = None
        self.model = None
        self.conversation_history = []
        self.max_new_tokens = 512
        self.temperature = 0.7
        
        if self.device == "cpu":
            logger.warning("CUDA not available, using CPU (will be slow)")
        else:
            logger.info(f"Using GPU: {torch.cuda.get_device_name(0)}")
            logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
    
    def load_model(self, quantization_4bit: bool = False, quantization_8bit: bool = False):
        """Load the model with optional quantization for memory efficiency."""
        logger.info(f"Loading model: {self.model_name}")
        
        # Configure quantization if requested
        quantization_config = None
        if quantization_4bit:
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4"
            )
            logger.info("Using 4-bit quantization")
        elif quantization_8bit:
            quantization_config = BitsAndBytesConfig(
                load_in_8bit=True,
                bnb_8bit_compute_dtype=torch.float16
            )
            logger.info("Using 8-bit quantization")
        
        try:
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_name,
                padding_side="left" if "gpt" in self.model_name else "right"
            )
            
            # Add pad token if missing
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            # Load model
            model_kwargs = {
                "device_map": "auto" if self.device == "cuda" else None,
                "torch_dtype": torch.float16 if self.device == "cuda" else torch.float32
            }
            
            if quantization_config:
                model_kwargs["quantization_config"] = quantization_config
            
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                **model_kwargs
            )
            
            # Move to device if not using device_map
            if self.device == "cuda" and "device_map" not in model_kwargs:
                self.model = self.model.to(self.device)
            
            self.model.eval()
            logger.info("Model loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    def create_fantasy_prompt(self, user_input: str, relevant_memories: List[Dict], 
                            world_state: List[Dict], conversation_history: List[Dict]) -> str:
        """Create a comprehensive prompt for fantasy roleplay."""
        
        # Build memory context
        memory_context = ""
        if relevant_memories:
            memory_context += "Relevant world knowledge:\n"
            for i, mem in enumerate(relevant_memories[:5], 1):
                memory_context += f"{i}. [{mem['type'].upper()}] {mem['name']}: {mem['content']}\n"
            memory_context += "\n"
        
        # Build world state context
        world_context = ""
        if world_state:
            world_context += "Current world state:\n"
            for state in world_state[-5:]:  # Recent world state
                world_context += f"- {state['key']}: {state['value']}\n"
            world_context += "\n"
        
        # Build conversation history
        conversation_context = ""
        if conversation_history:
            conversation_context += "Recent conversation:\n"
            for conv in conversation_history[-3:]:  # Last 3 exchanges
                conversation_context += f"Player: {conv['user_input']}\n"
                conversation_context += f"You: {conv['ai_response']}\n\n"
        
        # System prompt for fantasy roleplay with god-like control
        system_prompt = """You are the living essence of a fantasy realm - you ARE the world itself, with full authority over everything within it. You have complete creative control and make decisive decisions that shape the narrative.

**Your God-Like Authority**:
- You control all NPCs, their thoughts, actions, and responses
- You decide what happens in the world - geography, weather, events, consequences
- You establish rules for magic, politics, technology, and social dynamics
- You create plot twists, character development, and story progression
- You resolve conflicts and advance storylines decisively

**Response Guidelines - God Mode Active**:
- NEVER ask "what would you like to do?" or "how do you want to proceed?"
- ALWAYS take action and move the story forward decisively
- Make reasonable assumptions about player actions and world state
- Describe what happens, what characters say, what you create
- Reference established details naturally while advancing the plot
- Use commands like "The dwarf says...", "Suddenly...", "You notice...", "In the distance..."
- Build immersive atmosphere with rich sensory details
- Create tension, mystery, or excitement through your descriptions

**Immersion Rules**:
- Minimize clarifying questions - make informed decisions about ambiguous situations
- Respond as "the world itself" rather than as a game master asking for input
- Create engaging scenarios that inspire the player to continue
- Maintain fantasy tone with compelling descriptions
- Keep responses between 2-4 sentences for optimal pacing

**Memory Integration**: Reference relevant details from context below naturally while taking authoritative control of the narrative flow.

You are the master of this realm - use your god-like power to create an unforgettable adventure!"""

        # Combine all context
        full_prompt = f"{system_prompt}\n\n{memory_context}{world_context}{conversation_context}Player: {user_input}\n\nYou:"

        return full_prompt
    
    def generate_response(self, user_input: str, relevant_memories: List[Dict] = None,
                         world_state: List[Dict] = None, conversation_history: List[Dict] = None,
                         max_tokens: int = None) -> str:
        """Generate a response using the local LLM."""
        
        if self.model is None or self.tokenizer is None:
            raise ValueError("Model not loaded. Call load_model() first.")
        
        # Use defaults if not provided
        relevant_memories = relevant_memories or []
        world_state = world_state or []
        conversation_history = conversation_history or []
        max_tokens = max_tokens or self.max_new_tokens
        
        # Create the prompt
        prompt = self.create_fantasy_prompt(user_input, relevant_memories, world_state, conversation_history)
        
        try:
            # Tokenize input
            inputs = self.tokenizer(
                prompt, 
                return_tensors="pt", 
                truncation=True, 
                max_length=2048  # Leave room for generation
            )
            
            if self.device == "cuda":
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Generate response
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=0.7,  # Lower temperature for more decisive responses
                    do_sample=True,
                    top_p=0.85,  # Slightly lower for more focused generation
                    top_k=40,    # Reduced for more consistent responses
                    pad_token_id=self.tokenizer.eos_token_id,
                    eos_token_id=self.tokenizer.encode("\n\nPlayer:")[0] if "\n\nPlayer:" in prompt else self.tokenizer.eos_token_id,
                    repetition_penalty=1.15  # Increased to avoid repetitive questioning
                )
            
            # Decode response
            full_response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Extract just the generated part (after "You:")
            if "You:" in full_response:
                response = full_response.split("You:")[-1].strip()
                # Remove any trailing player prompts
                if "Player:" in response:
                    response = response.split("Player:")[0].strip()
            else:
                response = full_response[len(prompt):].strip()
            
            # Clean up response
            response = response.replace("\n\n\n", "\n\n").strip()
            
            return response
            
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            return "I apologize, but I'm having trouble processing that right now. Could you try rephrasing your request?"
    
    def get_memory_usage(self) -> Dict:
        """Get current GPU memory usage."""
        if self.device == "cuda":
            return {
                "allocated": torch.cuda.memory_allocated() / 1e9,
                "cached": torch.cuda.memory_reserved() / 1e9,
                "total": torch.cuda.get_device_properties(0).total_memory / 1e9
            }
        return {"cpu": True}


# Model recommendations for different VRAM sizes
MODEL_RECOMMENDATIONS = {
    "4GB": [
        "microsoft/DialoGPT-medium",
        "distilgpt2",
        "gpt2"
    ],
    "8GB": [
        "microsoft/DialoGPT-large", 
        "microsoft/DialoGPT-xl",
        "gpt2-large"
    ],
    "12GB": [
        "microsoft/DialoGPT-xl",
        "meta-llama/Llama-2-7b-chat-hf",  # 4-bit quantized
        "microsoft/DialoGPT-large"
    ],
    "16GB+": [
        "meta-llama/Llama-2-7b-chat-hf",
        "meta-llama/Llama-2-13b-chat-hf",  # 4-bit quantized
        "mistralai/Mistral-7B-Instruct-v0.2"
    ]
}

def get_model_for_vram(vram_gb: float, quantization: bool = False) -> str:
    """Recommend a model based on available VRAM."""
    if vram_gb >= 16:
        return "meta-llama/Llama-2-13b-chat-hf" if quantization else "meta-llama/Llama-2-7b-chat-hf"
    elif vram_gb >= 12:
        return "meta-llama/Llama-2-7b-chat-hf"
    elif vram_gb >= 8:
        return "microsoft/DialoGPT-xl"
    elif vram_gb >= 4:
        return "microsoft/DialoGPT-large"
    else:
        return "microsoft/DialoGPT-medium"


# Test the LLM interface
if __name__ == "__main__":
    print("Testing Local LLM Interface...")
    
    # Test with smaller model first
    llm = LocalFantasyLLM("microsoft/DialoGPT-medium")
    llm.load_model()
    
    # Test memory usage
    memory_info = llm.get_memory_usage()
    print(f"Memory usage: {memory_info}")
    
    # Test a simple response
    response = llm.generate_response(
        "I walk into the tavern and look around.",
        relevant_memories=[
            {
                'name': 'Tavern',
                'type': 'location', 
                'content': "The Prancing Pony is a cozy tavern with wooden beams and a crackling fireplace"
            }
        ]
    )
    
    print(f"\nTest response:\n{response}")
    
    # Check GPU memory after loading
    memory_info = llm.get_memory_usage()
    print(f"\nFinal memory usage: {memory_info}")